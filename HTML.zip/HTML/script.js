const bidForm = document.querySelector('.bid-form');
const highestBidder = document.querySelector('.highest-bidder');
let highestBid = 0;

bidForm.addEventListener('submit', function (event) {
    event.preventDefault();
    const bidInput = bidForm.querySelector('input[type="number"]');
    const bidAmount = parseFloat(bidInput.value);

    if (bidAmount > highestBid) {
        highestBid = bidAmount;
        highestBidder.querySelector('.bid-amount').textContent = highestBid;
    }

    bidInput.value = '';
});

document.getElementById('search-btn').addEventListener('click', function() {
    var searchQuery = document.getElementById('search-input').value;
    console.log('Search Query:', searchQuery);
   });